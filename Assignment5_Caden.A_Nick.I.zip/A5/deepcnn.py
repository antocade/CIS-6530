import os
from pathlib import Path
from collections import Counter

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

import matplotlib.pyplot as plt


DATA_PATH = Path("data_proc") / "grouped_chunks.csv"
SEED = 42
N_SPLITS = 3              
BATCH_SIZE = 16       
N_EPOCHS = 10         
EMBED_DIM = 8         
NUM_FILTERS = 64      
KERNEL_SIZE = 8       
HIDDEN_DIM = 16       
MAX_SEQ_LEN_CAP = 2000     

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")




def set_seed(seed=42):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def build_vocab(texts, min_freq=1):
    counter = Counter()
    for t in texts:
        counter.update(t.split())

    token_to_id = {"<PAD>": 0, "<UNK>": 1}
    for tok, freq in counter.items():
        if freq >= min_freq:
            token_to_id[tok] = len(token_to_id)

    return token_to_id


def texts_to_sequences(texts, token_to_id, max_len):
    pad_id = token_to_id["<PAD>"]
    unk_id = token_to_id["<UNK>"]

    seqs = []
    for t in texts:
        ids = [token_to_id.get(tok, unk_id) for tok in t.split()]
        ids = ids[:max_len]  # truncate
        if len(ids) < max_len:
            ids += [pad_id] * (max_len - len(ids))
        seqs.append(ids)

    return np.array(seqs, dtype=np.int64)


def print_confusion_matrix(cm, labels):
    """Pretty prints confusion matrix without warnings."""
    print("\nConfusion Matrix:")
    header = "          " + "  ".join(f"{lbl:10}" for lbl in labels)
    print(header)
    for i, row in enumerate(cm):
        row_str = "  ".join(f"{val:<10}" for val in row)
        print(f"{labels[i]:10} {row_str}")


def plot_confusion_matrix(cm, labels, fold_number):
    """Saves a heatmap-style confusion matrix plot to ./deepPlots/ using a nice blue theme."""
    plt.figure(figsize=(6, 5))
    plt.imshow(cm, interpolation='nearest', cmap="Blues") 
    plt.title(f"Confusion Matrix - Fold {fold_number}")
    plt.colorbar()

    ticks = range(len(labels))
    plt.xticks(ticks, labels, rotation=45)
    plt.yticks(ticks, labels)

    # Cells
    for i in range(len(labels)):
        for j in range(len(labels)):
            plt.text(
                j, i, cm[i, j],
                ha="center", va="center",
                fontsize=12
            )

    plt.ylabel("True Label")
    plt.xlabel("Predicted Label")
    plt.tight_layout()

    os.makedirs("deepPlots", exist_ok=True)
    out_path = f"deepPlots/fold{fold_number}.png"
    plt.savefig(out_path)
    plt.close()
    print(f"Saved confusion matrix plot to {out_path}")


class OpcodeDataset(Dataset):
    def __init__(self, sequences, labels):
        self.sequences = torch.as_tensor(sequences, dtype=torch.long)
        self.labels = torch.as_tensor(labels, dtype=torch.long)

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        return self.sequences[idx], self.labels[idx]


class CNNMalwareDetector(nn.Module):
    """Exact architecture from 'Deep Android Malware Detection' paper."""

    def __init__(self, vocab_size, num_classes):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, EMBED_DIM, padding_idx=0)
        self.conv = nn.Conv1d(
            in_channels=EMBED_DIM,
            out_channels=NUM_FILTERS,
            kernel_size=KERNEL_SIZE,
            padding=KERNEL_SIZE // 2
        )
        self.relu = nn.ReLU()
        self.fc1 = nn.Linear(NUM_FILTERS, HIDDEN_DIM)
        self.fc2 = nn.Linear(HIDDEN_DIM, num_classes)

    def forward(self, x):
        emb = self.embedding(x)         
        emb = emb.permute(0, 2, 1)        
        conv_out = self.relu(self.conv(emb))
        pooled, _ = torch.max(conv_out, dim=2)
        h = self.relu(self.fc1(pooled))
        return self.fc2(h)


def train_one_epoch(model, loader, optimizer, criterion):
    model.train()
    total_loss = 0

    for batch_x, batch_y in loader:
        batch_x = batch_x.to(device)
        batch_y = batch_y.to(device)

        optimizer.zero_grad()
        logits = model(batch_x)
        loss = criterion(logits, batch_y)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * batch_x.size(0)

    return total_loss / len(loader.dataset)


def eval_model(model, loader):
    model.eval()
    all_logits, all_labels = [], []

    with torch.no_grad():
        for batch_x, batch_y in loader:
            logits = model(batch_x.to(device))
            all_logits.append(logits.cpu().numpy())
            all_labels.append(batch_y.numpy())

    all_logits = np.concatenate(all_logits)
    all_labels = np.concatenate(all_labels)

    preds = np.argmax(all_logits, axis=1)
    acc = accuracy_score(all_labels, preds)
    macro_f1 = f1_score(all_labels, preds, average="macro")

    return acc, macro_f1, all_labels, preds


def run_cnn_kfold():
    set_seed(SEED)

    df = pd.read_csv(DATA_PATH)
    print(df.head())
    print(df["label"].value_counts())

    df["label"] = df["label"].astype("category")
    label_to_idx = {cat: i for i, cat in enumerate(df["label"].cat.categories)}
    idx_to_label = {i: cat for cat, i in label_to_idx.items()}

    y = df["label"].map(label_to_idx).values
    X_text = df["text"].values
    groups = df["group"].values
    num_classes = len(label_to_idx)

    sgkf = StratifiedGroupKFold(n_splits=N_SPLITS, shuffle=True, random_state=SEED)

    fold_metrics = []
    os.makedirs("deepPlots", exist_ok=True)

    for fold, (train_idx, test_idx) in enumerate(sgkf.split(X_text, y, groups), start=1):
        print(f"\n========== Fold {fold}/{N_SPLITS} ==========")

        X_train_text = X_text[train_idx]
        y_train = y[train_idx]
        X_test_text = X_text[test_idx]
        y_test = y[test_idx]

        token_to_id = build_vocab(X_train_text)
        vocab_size = len(token_to_id)
        print(f"Vocab size: {vocab_size}")

        train_lengths = [len(t.split()) for t in X_train_text]
        max_len = min(int(np.percentile(train_lengths, 95)), MAX_SEQ_LEN_CAP)
        max_len = max(max_len, KERNEL_SIZE)
        print(f"Max seq len: {max_len}")

        X_train_seq = texts_to_sequences(X_train_text, token_to_id, max_len)
        X_test_seq = texts_to_sequences(X_test_text, token_to_id, max_len)

        train_ds = OpcodeDataset(X_train_seq, y_train)
        test_ds = OpcodeDataset(X_test_seq, y_test)

        train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True)
        test_loader = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False)

        model = CNNMalwareDetector(vocab_size, num_classes).to(device)

        class_counts = np.bincount(y_train, minlength=num_classes)
        weights = class_counts.sum() / (len(class_counts) * class_counts)
        weights = torch.as_tensor(weights, dtype=torch.float32).to(device)

        criterion = nn.CrossEntropyLoss(weight=weights)
        optimizer = torch.optim.RMSprop(model.parameters(), lr=1e-2)

        for epoch in range(1, N_EPOCHS + 1):
            train_loss = train_one_epoch(model, train_loader, optimizer, criterion)
            acc, macro_f1, _, _ = eval_model(model, test_loader)
            print(f"Epoch {epoch:02d} - TrainLoss: {train_loss:.4f}, Acc: {acc:.4f}, Macro-F1: {macro_f1:.4f}")

        acc, macro_f1, y_true, y_pred = eval_model(model, test_loader)

        present_labels = sorted(set(y_true) | set(y_pred))
        label_names = [idx_to_label[i] for i in present_labels]

        print("\nClassification Report:")
        print(classification_report(
            y_true, y_pred, labels=present_labels, target_names=label_names
        ))

        cm = confusion_matrix(y_true, y_pred, labels=present_labels)
        print_confusion_matrix(cm, label_names)
        plot_confusion_matrix(cm, label_names, fold)

        fold_metrics.append((acc, macro_f1))

    print("\n========== CNN Summary ==========")
    accs = [a for a, _ in fold_metrics]
    f1s = [f for _, f in fold_metrics]
    print(f"Mean Accuracy: {np.mean(accs):.3f} ± {np.std(accs):.3f}")
    print(f"Mean Macro-F1: {np.mean(f1s):.3f} ± {np.std(f1s):.3f}")


if __name__ == "__main__":
    run_cnn_kfold()
